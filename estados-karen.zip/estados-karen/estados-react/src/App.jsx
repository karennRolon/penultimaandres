import { useState } from 'react'
import './App.css'
import Final from './components/Final'


function App() {
  

  return (
    <div className="App">
      <Final 
   

   /> 
    </div>
  )
}

export default App
